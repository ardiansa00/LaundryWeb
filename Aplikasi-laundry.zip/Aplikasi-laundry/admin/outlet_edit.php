<?php
$title = 'outlet';
require'functions.php';
$query = 'SELECT outlet.*, user.nama_user,user.id_user FROM outlet LEFT JOIN user ON user.outlet_id = outlet.id_outlet WHERE id_outlet = ' . $_GET['id'];
$data = ambilsatubaris($conn,$query);

$query2 = 'SELECT user.*,outlet.nama_outlet FROM outlet RIGHT JOIN user ON user.outlet_id = outlet.id_outlet WHERE user.role = "owner" order by user.outlet_id asc';
$data2 = ambildata($conn,$query2);
if(isset($_POST['btn-simpan'])){
    $nama   = $_POST['nama_outlet'];
    $alamat = $_POST['alamat_outlet'];
    $telp   = $_POST['telp_outlet'];

    $query = "UPDATE outlet SET nama_outlet = '$nama' , alamat_outlet = '$alamat' , telp_outlet='$telp' WHERE id_outlet = " . $_GET['id'];
    
    
    if($_POST['owner_id_new']){
        $query2 = "UPDATE user SET outlet_id = '" . $_GET['id'] . "' WHERE id_user = " . $_POST['owner_id_new'];
        $query3 = "UPDATE user SET outlet_id = NULL WHERE id_user = " . $data['id_user'];
        $execute3 = bisa($conn,$query3);
    }else{
        $query2 = "UPDATE user SET outlet_id = '" . $_GET['id'] . "' WHERE id_user = " . $_POST['owner_id'];
    }

    $execute = bisa($conn,$query);
    $execute2 = bisa($conn,$query2);

    if($execute == 1 && $execute2 == 1){
        $success = 'true';
        $title = 'Berhasil';
        $message = 'Berhasil Mengubah Data';
        $type = 'success';
        header('location: outlet.php?crud='.$success.'&msg='.$message.'&type='.$type.'&title='.$title);
    }else{
        echo "Gagal Tambah Data";
    }
}


require'layout_header.php';
?> 
<div class="container-fluid">
    <div class="row">
        <div class="col-md-12 col-lg-12 col-sm-12 col-xs-12 mt-4">
            <div class="white-box">
                <form method="post" action="">
                <div class="form-group">
                    <label>Nama Outlet</label>
                    <input autocomplete="off" type="text" value="<?= $data['nama_outlet']; ?>" name="nama_outlet" class="form-control">
                </div>
                <div class="form-group">
                    <label>Alamat Outlet</label>
                    <textarea autocomplete="off" name="alamat_outlet" class="form-control"><?= $data['alamat_outlet']; ?></textarea>
                </div>
                <div class="form-group">
                    <label>Nomor Telepon</label>
                    <input autocomplete="off" type="text" value="<?= $data['telp_outlet']; ?>" name="telp_outlet" class="form-control">
                </div>
                <?php if($data['nama_user']  == null): ?>
                    <div class="form-group">
                        <label>Belum Ada Owner (silahkan pilih owner)</label>
                        <select name="owner_id" class="form-control">
                            <?php foreach ($data2 as $owner): ?>
                                <option value="<?= $owner['id_user'] ?>"><?= $owner['nama_user'] ?> 
                                    <?php if ($owner['outlet_id'] == null): ?>
                                        ( Belum memiliki outlet )
                                    <?php else: ?>
                                        ( Owner di <?= $owner['nama_outlet'] ?> )
                                    <?php endif ?>                                    
                                </option>
                            <?php endforeach ?>
                        </select>
                    </div>
                <?php else: ?>
                    <div class="form-group">
                        <label>Owner Sekarang : <?= $data['nama_user']; ?></label>
                        <select name="owner_id_new" class="form-control">
                            <option class="">Pilih Untuk Mengganti owner</option>
                            <?php foreach ($data2 as $owner): ?>
                                <option value="<?= $owner['id_user'] ?>"><?= $owner['nama_user'] ?> 
                                    <?php if ($owner['outlet_id'] == null): ?>
                                        ( Belum memiliki outlet )
                                    <?php else: ?>
                                        ( Owner di <?= $owner['nama_outlet'] ?> )
                                    <?php endif ?>                                    
                                </option>
                            <?php endforeach ?>
                        </select>
                    </div>
                <?php endif; ?>
                <div class="text-right">
					<a href="javascript:void(0)" onclick="window.history.back();" class="btn btn-primary"><i class="fa fa-arrow-left fa-fw"></i> Kembali</a>
                    <button type="reset" class="btn btn-danger"><i class="fa fa-refresh fa-fw"></i> Reset</button>
                    <button type="submit" name="btn-simpan" class="btn btn-success"><i class="fa fa-save fa-fw"></i> Simpan</button>
                </div>
                </form>
            </div>
        </div>
    </div>
</div>
<?php
require'layout_footer.php';
?> 